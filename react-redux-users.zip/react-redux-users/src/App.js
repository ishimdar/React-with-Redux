import React from 'react';
// import logo from './logo.svg';

import SearchUserList from './components/userlist/index';
// import './App.css';

function App() {
  return (
    <div className="App col-sm-12">      
      <SearchUserList />
    </div>
  );
}

export default App;
